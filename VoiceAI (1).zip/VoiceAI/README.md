# VoiceAI — Your Voice. Your Phone. Your Control.

Native Android app (Kotlin, Jetpack Compose, Material 3, MVVM, coroutines). Push-to-talk voice assistant for English, Urdu and Roman Urdu.

## What works (and how)
| Feature | Mechanism |
|---|---|
| Speech-to-text | `SpeechRecognizer` (live partial results, waveform from mic level) |
| Understanding | On-device rule parser (EN / اردو / Roman Urdu, mixed sentences, follow-up questions) + optional cloud AI via `AIService` |
| Open apps | Launch intents for an allowlist: WhatsApp, YouTube, TikTok, Phone, Camera, Google, Chrome, Maps, Gmail, Calendar, Settings. "Not installed" is reported honestly |
| WhatsApp message | Contact lookup → confirmation → opens WhatsApp chat with the text pre-filled via `wa.me`. **You tap Send in WhatsApp.** History shows "Ready in app", never "Sent" |
| Calls | Contact lookup → confirmation → `ACTION_CALL` if Phone permission granted, otherwise opens the dialer |
| YouTube search | `ACTION_SEARCH` to the YouTube app; falls back to opening YouTube / browser and says so |
| Google search | Browser intent |
| TTS | `TextToSpeech`, speed + voice choice |
| History / Favorites / Shortcuts | Local SQLite |
| Themes | Cream, System, Dark |

## Honest limitations
* **Wake word / "Hey VoiceAI" is NOT implemented.** The setting is shown disabled with an explanation. Always-on listening needs a visible foreground service plus an on-device keyword model; it was deliberately not faked.
* Android and WhatsApp do not let apps press Send or read chats, so messages are *prepared*, not auto-sent.
* Roman Urdu speech uses the `en-IN` recognizer; accuracy depends on the device's speech service. Urdu script uses `ur-PK`.
* Speech recognition may be processed online by the device's speech service (disclosed in Settings → Privacy).
* Multiple shortcut apps are launched one after another; Android may block background launches on some devices.
* Default country code for local numbers (`0300…`) is `92` (see `AppSettings.countryCode`).
* This source was written without a build environment — open it in Android Studio and let Gradle sync; fix any version nits it reports.

## Architecture
`SpeechService → CommandParser (LocalParser / AIService) → missing-slot questions → ActionExecutor (permission checks, contact resolve, Interaction confirm) → Android Intent → ActionResult → VoiceResponseService + History`

* `core/` AIService, CommandParser, LocalParser, SpeechService, VoiceResponseService, ActionExecutor, ContactResolver, Apps
* `data/` Prefs (non-sensitive settings), Store (SQLite)
* `ui/` Compose screens; `AssistantViewModel` drives the pipeline
* Security: command allowlist (`Command` sealed type), no shell execution, no API keys in the app, cloud responses are validated against the allowlist.

## 1. Open in Android Studio
Android Studio Koala (2024.1) or newer, JDK 17. *File → Open →* the `VoiceAI` folder, wait for Gradle sync (downloads Gradle 8.7, AGP 8.5.2, Kotlin 2.0.20).
(For command-line builds run `gradle wrapper` once to generate `gradlew`.)

## 2. API keys (optional cloud AI)
The app contains **no AI keys**. Run your own HTTPS endpoint that calls your AI provider and returns
`{"commands":[{"intent":"OPEN_APP|SEND_MESSAGE|CALL|SEARCH","app":"whatsapp","contact":"Ali","message":"…","query":"…"}]}`
for `POST {"text":"…"}`. Put its URL in `local.properties` (git-ignored): `voiceai.backendUrl=https://…`. Without it, Cloud AI is disabled and everything runs on-device.

## 3. Permissions
Declared: `RECORD_AUDIO`, `READ_CONTACTS`, `CALL_PHONE`, `INTERNET`, `ACCESS_NETWORK_STATE`. Each is requested only after an explanation (onboarding or on first use). Denials never crash; the app explains what stops working and links to system Settings.

## 4. Debug APK
`Build → Build Bundle(s)/APK(s) → Build APK(s)` → `app/build/outputs/apk/debug/app-debug.apk`
or `./gradlew assembleDebug`.

## 5. Release APK
Create a keystore (`keytool -genkey -v -keystore voiceai-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias voiceai`), copy `keystore.properties.example` → `keystore.properties`, fill it in, then `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`.

## 6. Install on a phone
Enable Developer options + USB debugging, then `adb install -r app-debug.apk` — or copy the APK to the phone and open it (allow "Install unknown apps").

## Website + automatic APK (GitHub)
* `index.html` at the repo root is the landing page. Enable **Settings → Pages → Deploy from a branch → main → / (root)**.
* `.github/workflows/build-apk.yml` builds the APK on every push to `main` and publishes it as `VoiceAI.apk` in **Releases → latest**. The website's Download button links there automatically.
* In **Settings → Actions → General → Workflow permissions** choose "Read and write permissions".
