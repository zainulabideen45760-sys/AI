# Default Android/Compose rules are sufficient: VoiceAI uses no reflection-based libraries.
