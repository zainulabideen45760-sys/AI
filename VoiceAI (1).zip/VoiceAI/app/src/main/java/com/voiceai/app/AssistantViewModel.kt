package com.voiceai.app

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.voiceai.app.core.*
import com.voiceai.app.data.AppSettings
import com.voiceai.app.data.Status
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Phase { IDLE, LISTENING, UNDERSTANDING, PREPARING, SPEAKING }
enum class ReplyKind { NONE, INFO, SUCCESS, ERROR }
data class ConfirmRequest(val title: String, val detail: String, val okLabel: String)
data class ChooseRequest(val title: String, val options: List<String>)

data class UiState(
    val phase: Phase = Phase.IDLE,
    val partial: String = "",
    val heard: String = "",
    val reply: String = "",
    val replyKind: ReplyKind = ReplyKind.NONE,
    val replyNeedsSettings: Boolean = false,
    val level: Float = 0f,
    val confirm: ConfirmRequest? = null,
    val choose: ChooseRequest? = null,
)

/**
 * Pipeline: Speech → Parser → (ask for missing info) → Permission check + Executor → Confirmation → Android intent → Result → Voice response.
 */
class AssistantViewModel(app: Application) : AndroidViewModel(app) {
    private val a = VoiceAIApp.of(app)
    val settings: StateFlow<AppSettings> = a.prefs.state
    val history = a.store.history
    val favorites = a.store.favorites
    val shortcuts = a.store.shortcuts
    val launcher get() = a.launcher
    val cloudAvailable get() = a.cloudAvailable

    private val _ui = MutableStateFlow(UiState())
    val ui = _ui.asStateFlow()

    private var job: Job? = null
    private var pending: Pending? = null
    private var confirmD: CompletableDeferred<Boolean>? = null
    private var chooseD: CompletableDeferred<Int?>? = null

    private enum class Slot { CONTACT, MESSAGE, QUERY }
    private class Pending(val cmds: List<Command>, val origin: String)

    init { a.voice } // warm up text-to-speech

    // ---------- interaction (confirmations & choices) ----------
    private val interaction = object : Interaction {
        override suspend fun confirm(title: String, detail: String, okLabel: String): Boolean {
            val d = CompletableDeferred<Boolean>(); confirmD = d
            _ui.update { it.copy(confirm = ConfirmRequest(title, detail, okLabel)) }
            a.voice.speakNow(title)
            return try { d.await() } finally { _ui.update { it.copy(confirm = null) }; confirmD = null }
        }
        override suspend fun choose(title: String, options: List<String>): Int? {
            val d = CompletableDeferred<Int?>(); chooseD = d
            _ui.update { it.copy(choose = ChooseRequest(title, options)) }
            a.voice.speakNow(title)
            return try { d.await() } finally { _ui.update { it.copy(choose = null) }; chooseD = null }
        }
    }
    fun answerConfirm(ok: Boolean) { confirmD?.complete(ok) }
    fun answerChoose(index: Int?) { chooseD?.complete(index) }

    // ---------- entry points ----------
    fun onMic() {
        when (_ui.value.phase) {
            Phase.IDLE -> launchTurn { true }
            Phase.LISTENING -> a.speech.stop()
            Phase.SPEAKING -> cancel()
            else -> {}
        }
    }
    fun micDenied() = showError("Microphone permission is needed to hear you. You can enable it in Settings.", settings = true, speak = false)
    fun submit(text: String) { pending = null; launchTurn { process(text) } }
    fun run(origin: String, cmds: List<Command>) { pending = null; launchTurn { runCommands(origin, cmds, null) } }

    fun quick(app: AppKey) {
        val c: Command? = when (app) {
            AppKey.WHATSAPP -> Command.SendMessage(AppKey.WHATSAPP, null, null)
            AppKey.PHONE -> Command.Call(null)
            AppKey.YOUTUBE -> Command.Search(AppKey.YOUTUBE, null)
            AppKey.GOOGLE -> Command.Search(AppKey.GOOGLE, null)
            else -> null
        }
        if (c == null) { run("Open ${app.label}", listOf(Command.OpenApp(app))); return }
        pending = Pending(listOf(c), "${app.label} ${app.blurb.lowercase()}")
        launchTurn { reply(question(c, missing(c)!!)); true }
    }

    fun cancel() {
        job?.cancel(); a.voice.stop()
        confirmD?.complete(false); chooseD?.complete(null)
        toIdle()
    }

    // ---------- turn loop ----------
    private fun launchTurn(body: suspend () -> Boolean) {
        job?.cancel(); a.voice.stop()
        job = viewModelScope.launch {
            try {
                var again = body()
                while (again) { val t = listenOnce(); again = if (t == null) false else process(t) }
            } catch (e: CancellationException) { throw e } catch (e: Exception) {
                showError("Something went wrong. Please try again.")
            }
            toIdle()
        }
    }

    private fun toIdle() = _ui.update { it.copy(phase = Phase.IDLE, partial = "", level = 0f) }

    private suspend fun listenOnce(): String? {
        val ctx = getApplication<Application>()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { micDenied(); return null }
        if (!a.speech.isAvailable()) { showError("Speech recognition isn't available on this device. Install or enable Google's speech service."); return null }
        _ui.update { it.copy(phase = Phase.LISTENING, partial = "", heard = "", replyKind = ReplyKind.NONE, reply = "", replyNeedsSettings = false) }
        var final: String? = null
        var err: SpeechError? = null
        a.speech.listen(settings.value.language.tag).collect { ev ->
            when (ev) {
                is SpeechEvent.Partial -> _ui.update { it.copy(partial = ev.text) }
                is SpeechEvent.Level -> _ui.update { it.copy(level = ev.value) }
                is SpeechEvent.Final -> final = ev.text
                is SpeechEvent.Error -> err = ev.kind
            }
        }
        err?.let { showError(errorText(it), settings = it == SpeechError.NO_PERMISSION); return null }
        return final?.takeIf { it.isNotBlank() }
    }

    private fun errorText(k: SpeechError) = when (k) {
        SpeechError.NO_MATCH -> "I couldn't understand that. Please try again."
        SpeechError.NETWORK -> "Internet connection required for speech recognition on this device."
        SpeechError.NO_PERMISSION -> "Microphone permission is needed to hear you. You can enable it in Settings."
        SpeechError.UNAVAILABLE -> "Speech recognition isn't available for the selected language on this device. Try another language in Settings."
        SpeechError.BUSY -> "Speech recognition is busy. Please try again."
        SpeechError.OTHER -> "Something went wrong with speech recognition. Please try again."
    }

    // ---------- understanding ----------
    private suspend fun process(text: String): Boolean {
        _ui.update { it.copy(phase = Phase.UNDERSTANDING, heard = text, partial = "", replyKind = ReplyKind.NONE, reply = "") }
        val p = pending
        if (p != null) {
            if (LocalParser.isCancel(text)) { pending = null; reply("Okay, cancelled."); return false }
            val idx = p.cmds.indexOfFirst { missing(it) != null }
            val filled = p.cmds.toMutableList().also { it[idx] = fill(it[idx], missing(it[idx])!!, text) }
            pending = null
            return runCommands(p.origin, filled, null)
        }
        val n = LocalParser.norm(text)
        val sc = shortcuts.value.firstOrNull { it.name.isNotBlank() && n.contains(LocalParser.norm(it.name)) }
        if (sc != null) {
            val cmds = sc.apps.mapNotNull { AppKey.fromName(it) }.map { Command.OpenApp(it) }
            return runCommands(sc.name, cmds, "Starting ${sc.name}.")
        }
        return runCommands(text, a.parser.parse(text), null)
    }

    private fun missing(c: Command): Slot? = when (c) {
        is Command.SendMessage -> if (c.contact.isNullOrBlank()) Slot.CONTACT else if (c.message.isNullOrBlank()) Slot.MESSAGE else null
        is Command.Call -> if (c.contact.isNullOrBlank()) Slot.CONTACT else null
        is Command.Search -> if (c.query.isNullOrBlank()) Slot.QUERY else null
        else -> null
    }

    private fun fill(c: Command, s: Slot, t: String): Command = when {
        c is Command.SendMessage && s == Slot.CONTACT -> c.copy(contact = LocalParser.extractName(t))
        c is Command.SendMessage && s == Slot.MESSAGE -> c.copy(message = LocalParser.cleanMessage(t))
        c is Command.Call -> c.copy(contact = LocalParser.extractName(t))
        c is Command.Search -> c.copy(query = LocalParser.cleanQuery(t))
        else -> c
    }

    private fun question(c: Command, s: Slot): String = when (s) {
        Slot.CONTACT -> if (c is Command.SendMessage) "Who should I message?" else "Who should I call?"
        Slot.MESSAGE -> "What would you like me to send to ${(c as Command.SendMessage).contact}?"
        Slot.QUERY -> "What should I search for${if ((c as Command.Search).engine == AppKey.YOUTUBE) " on YouTube" else ""}?"
    }

    /** Returns true when a follow-up question was asked and VoiceAI should listen again. */
    private suspend fun runCommands(origin: String, cmds: List<Command>, speechOverride: String?): Boolean {
        val gap = cmds.indexOfFirst { missing(it) != null }
        if (gap >= 0) {
            pending = Pending(cmds, origin)
            reply(question(cmds[gap], missing(cmds[gap])!!))
            return true
        }
        if (cmds.isEmpty()) { showError("I couldn't find anything to do for that."); return false }
        _ui.update { it.copy(phase = Phase.PREPARING) }
        var last: ActionResult? = null
        for ((i, c) in cmds.withIndex()) {
            if (i > 0) delay(700)
            val r = a.executor.execute(c, interaction)
            if (settings.value.saveHistory) a.store.addHistory(origin, r.summary, r.status)
            last = r
            if (r.status == Status.FAILED || r.status == Status.CANCELLED) break
        }
        last?.let { r ->
            val said = if (speechOverride != null && r.status != Status.FAILED && r.status != Status.CANCELLED) speechOverride else r.speech
            _ui.update {
                it.copy(phase = Phase.SPEAKING, reply = said, replyNeedsSettings = r.needsSettings,
                    replyKind = if (r.status == Status.FAILED) ReplyKind.ERROR else if (r.status == Status.CANCELLED) ReplyKind.INFO else ReplyKind.SUCCESS)
            }
            a.voice.speak(said)
        }
        return false
    }

    private suspend fun reply(text: String) {
        _ui.update { it.copy(phase = Phase.SPEAKING, reply = text, replyKind = ReplyKind.INFO, replyNeedsSettings = false) }
        a.voice.speak(text)
    }

    private fun showError(msg: String, settings: Boolean = false, speak: Boolean = true) {
        _ui.update { it.copy(phase = Phase.IDLE, reply = msg, replyKind = ReplyKind.ERROR, replyNeedsSettings = settings, level = 0f) }
        if (speak) a.voice.speakNow(msg)
    }

    // ---------- settings & storage helpers used by the UI ----------
    fun updateSettings(f: (AppSettings) -> AppSettings) = a.prefs.update(f)
    fun toggleFavoriteApp(key: String) = a.prefs.update { s ->
        s.copy(favoriteApps = if (key in s.favoriteApps) s.favoriteApps - key else s.favoriteApps + key)
    }
    fun addFavorite(text: String) = a.store.addFavorite(text)
    fun deleteFavorite(id: Long) = a.store.deleteFavorite(id)
    fun addShortcut(name: String, apps: List<String>) = a.store.addShortcut(name, apps)
    fun deleteShortcut(id: Long) = a.store.deleteShortcut(id)
    fun clearHistory() = a.store.clearHistory()

    override fun onCleared() { a.voice.stop() }
}
