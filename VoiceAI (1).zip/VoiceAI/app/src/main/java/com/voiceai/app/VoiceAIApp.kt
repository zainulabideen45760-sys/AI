package com.voiceai.app

import android.app.Application
import android.content.Context
import com.voiceai.app.core.*
import com.voiceai.app.data.Prefs
import com.voiceai.app.data.Store

/** Tiny manual dependency container: swap implementations here (e.g. a different AIService). */
class VoiceAIApp : Application() {
    val prefs by lazy { Prefs(this) }
    val store by lazy { Store(this) }
    val launcher by lazy { AppLauncher(this) }
    val contacts by lazy { ContactResolver(this) }
    val speech by lazy { SpeechService(this) }
    val voice by lazy { VoiceResponseService(this, prefs) }
    private val remote: AIService? by lazy {
        BuildConfig.BACKEND_URL.takeIf { it.startsWith("https://") }?.let { RemoteAIService(it) }
    }
    val cloudAvailable: Boolean get() = remote != null
    val parser by lazy { CommandParser(this, prefs, remote) }
    val executor by lazy { ActionExecutor(this, prefs, launcher, contacts) }

    companion object { fun of(ctx: Context) = ctx.applicationContext as VoiceAIApp }
}
