package com.voiceai.app.core

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.voiceai.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

fun isOnline(ctx: Context): Boolean {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/** Swap in any AI provider by implementing this. Return null to fall back to the local parser. */
interface AIService {
    suspend fun interpret(text: String): List<Command>?
}

/**
 * Talks to YOUR backend (HTTPS only). The backend holds the real AI key and returns:
 * {"commands":[{"intent":"OPEN_APP|SEND_MESSAGE|CALL|SEARCH","app":"whatsapp","contact":"Ali","message":"...","query":"..."}]}
 * Only the text of the command is sent — never audio, contacts or history. The response is validated
 * against the fixed allowlist, so a backend can never make VoiceAI run anything outside it.
 */
class RemoteAIService(private val url: String) : AIService {
    override suspend fun interpret(text: String): List<Command>? = withContext(Dispatchers.IO) {
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 5000; c.readTimeout = 6000; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(JSONObject().put("text", text).toString().toByteArray()) }
            if (c.responseCode != 200) return@withContext null
            val arr = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("commands")
            (0 until arr.length()).mapNotNull { map(arr.getJSONObject(it)) }
        } catch (e: Exception) { null }
    }

    private fun map(o: JSONObject): Command? {
        val app = AppKey.fromName(o.optString("app"))
        fun s(k: String) = o.optString(k).trim().ifBlank { null }
        return when (o.optString("intent").uppercase()) {
            "OPEN_APP" -> app?.let { Command.OpenApp(it) }
            "SEND_MESSAGE" -> Command.SendMessage(app ?: AppKey.WHATSAPP, s("contact"), s("message"))
            "CALL" -> Command.Call(s("contact"))
            "SEARCH" -> Command.Search(if (app == AppKey.YOUTUBE) AppKey.YOUTUBE else AppKey.GOOGLE, s("query"))
            else -> null
        }
    }
}

class CommandParser(private val ctx: Context, private val prefs: Prefs, private val remote: AIService?) {
    suspend fun parse(text: String): List<Command> {
        if (remote != null && prefs.current.cloudAi && isOnline(ctx)) {
            remote.interpret(text)?.takeIf { it.isNotEmpty() }?.let { return it }
        }
        return LocalParser.parse(text)
    }
}
