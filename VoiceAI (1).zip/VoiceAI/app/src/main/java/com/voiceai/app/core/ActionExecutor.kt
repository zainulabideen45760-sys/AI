package com.voiceai.app.core

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import com.voiceai.app.data.Prefs
import com.voiceai.app.data.Status
import kotlinx.coroutines.CancellationException

/**
 * Runs allowlisted commands through official Android mechanisms only (intents / content providers).
 * It never claims success unless Android accepted the action, and never sends or calls without the
 * user's confirmation when "Confirm important actions" is on.
 */
class ActionExecutor(
    private val ctx: Context,
    private val prefs: Prefs,
    private val launcher: AppLauncher,
    private val contacts: ContactResolver,
) {
    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    private fun fail(speech: String, summary: String, settings: Boolean = false) = ActionResult(Status.FAILED, speech, summary, settings)
    private val cancelled = ActionResult(Status.CANCELLED, "Okay, cancelled.", "Cancelled")

    suspend fun execute(cmd: Command, ui: Interaction): ActionResult = try {
        when (cmd) {
            is Command.OpenApp -> openApp(cmd.app, ui)
            is Command.SendMessage -> sendMessage(cmd, ui)
            is Command.Call -> call(cmd, ui)
            is Command.Search -> search(cmd)
            is Command.Unknown -> fail("I couldn't understand that. Please try again.", "Not understood")
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        fail("Something went wrong. Please try again.", "Failed")
    }

    private suspend fun openApp(app: AppKey, ui: Interaction): ActionResult {
        if (!launcher.isInstalled(app)) return fail("${app.label} is not installed on this device.", "${app.label} not installed")
        if (!prefs.current.autoOpen && !ui.confirm("Open ${app.label}?", "VoiceAI will open ${app.label}.", "Open")) return cancelled
        return if (launcher.launch(app)) ActionResult(Status.COMPLETED, "Opening ${app.label}.", "Opened ${app.label}")
        else fail("I couldn't open ${app.label}.", "Couldn't open ${app.label}")
    }

    /** Resolves a spoken name to one contact; asks the user when several match. */
    private suspend fun pickContact(name: String, ui: Interaction): Pair<ContactMatch?, ActionResult?> {
        if (!has(Manifest.permission.READ_CONTACTS))
            return null to fail("I need Contacts permission to find $name. You can enable it in Settings.", "Contacts permission needed", true)
        val m = contacts.find(name)
        if (m.isEmpty()) return null to fail("I couldn't find a contact named $name.", "Contact not found: $name")
        val exact = m.filter { it.name.equals(name, true) }
        if (exact.size == 1) return exact[0] to null
        if (m.size == 1) return m[0] to null
        val i = ui.choose("I found ${m.size} contacts named $name. Please choose one.", m.map { it.name }) ?: return null to cancelled
        return m[i] to null
    }

    private fun whatsappDigits(c: ContactMatch): String? {
        val raw = (c.normalized ?: c.number).filter { it.isDigit() || it == '+' }
        val d = when {
            raw.startsWith("+") -> raw.drop(1)
            raw.startsWith("00") -> raw.drop(2)
            raw.startsWith("0") -> prefs.current.countryCode + raw.drop(1)
            else -> raw
        }
        return d.ifBlank { null }
    }

    private suspend fun sendMessage(cmd: Command.SendMessage, ui: Interaction): ActionResult {
        if (cmd.app != AppKey.WHATSAPP) return fail("Messaging through ${cmd.app.label} isn't supported yet.", "Unsupported messaging app")
        val pkg = launcher.installedPackage(AppKey.WHATSAPP) ?: return fail("WhatsApp is not installed on this device.", "WhatsApp not installed")
        val name = cmd.contact ?: return fail("I need to know who to message.", "No contact")
        val msg = cmd.message ?: return fail("I need to know what to send.", "No message")
        val (contact, err) = pickContact(name, ui)
        if (contact == null) return err ?: cancelled
        val digits = whatsappDigits(contact) ?: return fail("${contact.name} doesn't have a usable phone number.", "No phone number")
        if (prefs.current.confirmImportant &&
            !ui.confirm("Send this message?", "To: ${contact.name}\n\n“$msg”\n\nWhatsApp will open with this message ready. You tap Send there.", "Open in WhatsApp")) return cancelled
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=${Uri.encode(msg)}")).setPackage(pkg)
        // Android/WhatsApp don't let apps press Send for you, so this is "prepared", never "sent".
        return if (launcher.start(intent))
            ActionResult(Status.PREPARED, "Your message to ${contact.name} is ready in WhatsApp. Tap Send there to deliver it.", "WhatsApp message to ${contact.name} prepared")
        else fail("I couldn't open WhatsApp.", "Couldn't open WhatsApp")
    }

    private suspend fun call(cmd: Command.Call, ui: Interaction): ActionResult {
        if (!ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_TELEPHONY)) return fail("This device can't make phone calls.", "No telephony")
        val name = cmd.contact ?: return fail("I need to know who to call.", "No contact")
        val (contact, err) = pickContact(name, ui)
        if (contact == null) return err ?: cancelled
        if (prefs.current.confirmImportant && !ui.confirm("Call ${contact.name}?", contact.number, "Call")) return cancelled
        val uri = Uri.parse("tel:" + Uri.encode(contact.number))
        return if (has(Manifest.permission.CALL_PHONE)) {
            if (launcher.start(Intent(Intent.ACTION_CALL, uri))) ActionResult(Status.COMPLETED, "Calling ${contact.name}.", "Called ${contact.name}")
            else fail("I couldn't start the call.", "Call failed")
        } else {
            if (launcher.start(Intent(Intent.ACTION_DIAL, uri)))
                ActionResult(Status.PREPARED, "I opened the dialer with ${contact.name}'s number. Press call to continue.", "Dialer opened for ${contact.name}")
            else fail("I couldn't open the dialer.", "Dialer failed")
        }
    }

    private fun search(cmd: Command.Search): ActionResult {
        val q = cmd.query ?: return fail("What should I search for?", "No query")
        if (!isOnline(ctx)) return fail("Internet connection required for this command.", "Search needs internet")
        if (cmd.engine == AppKey.YOUTUBE) {
            val pkg = launcher.installedPackage(AppKey.YOUTUBE)
            if (pkg != null) {
                val ok = launcher.start(Intent(Intent.ACTION_SEARCH).setPackage(pkg).putExtra("query", q))
                if (ok) return ActionResult(Status.COMPLETED, "Searching YouTube for $q.", "YouTube search: $q")
                return if (launcher.launch(AppKey.YOUTUBE))
                    ActionResult(Status.PREPARED, "I opened YouTube, but I couldn't search automatically. Please search for $q there.", "Opened YouTube (search not automatic)")
                else fail("I couldn't open YouTube.", "Couldn't open YouTube")
            }
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
            return if (launcher.start(web)) ActionResult(Status.COMPLETED, "YouTube isn't installed, so I opened the results in your browser.", "YouTube search in browser: $q")
            else fail("I couldn't open a browser.", "No browser")
        }
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
        return if (launcher.start(web)) ActionResult(Status.COMPLETED, "Searching Google for $q.", "Google search: $q")
        else fail("I couldn't open a browser.", "No browser")
    }
}
