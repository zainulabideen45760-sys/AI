package com.voiceai.app.core

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.provider.MediaStore
import android.provider.Settings as AndroidSettings

/** Allowlist of apps VoiceAI can open. Nothing outside this list is ever launched. */
enum class AppKey(val label: String, val blurb: String, val aliases: List<String>, val packages: List<String> = emptyList()) {
    WHATSAPP("WhatsApp", "Send a message", listOf("whatsapp", "whats app", "watsapp", "واٹس ایپ", "واٹس اپ", "واٹسایپ", "وٹس ایپ"), listOf("com.whatsapp", "com.whatsapp.w4b")),
    YOUTUBE("YouTube", "Search videos", listOf("youtube", "you tube", "یوٹیوب", "یو ٹیوب"), listOf("com.google.android.youtube")),
    TIKTOK("TikTok", "Open TikTok", listOf("tiktok", "tik tok", "ٹک ٹاک", "ٹکٹاک"), listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")),
    PHONE("Phone", "Make a call", listOf("dialer", "phone app", "ڈائلر")),
    CAMERA("Camera", "Open camera", listOf("camera", "کیمرہ", "کیمرا")),
    GOOGLE("Google", "Search the web", listOf("google", "گوگل"), listOf("com.google.android.googlequicksearchbox")),
    CHROME("Chrome", "Browse the web", listOf("chrome", "کروم"), listOf("com.android.chrome")),
    MAPS("Maps", "Find places", listOf("google maps", "maps", "map", "میپس", "نقشہ"), listOf("com.google.android.apps.maps")),
    GMAIL("Gmail", "Check email", listOf("gmail", "جی میل"), listOf("com.google.android.gm")),
    CALENDAR("Calendar", "Your schedule", listOf("calendar", "کیلنڈر"), listOf("com.google.android.calendar")),
    SETTINGS("Settings", "Device settings", listOf("settings", "setting", "سیٹنگز", "سیٹنگ"));

    companion object {
        fun fromName(n: String?): AppKey? = values().firstOrNull { it.name.equals(n, true) }
    }
}

class AppLauncher(private val ctx: Context) {
    private val pm = ctx.packageManager

    private fun intentFor(app: AppKey): Intent? = when (app) {
        AppKey.PHONE -> Intent(Intent.ACTION_DIAL)
        AppKey.CAMERA -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA) // opens camera; never takes a photo
        AppKey.SETTINGS -> Intent(AndroidSettings.ACTION_SETTINGS)
        else -> app.packages.firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) }
    }?.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

    fun isInstalled(app: AppKey): Boolean = intentFor(app)?.resolveActivity(pm) != null

    /** First installed package name for apps that have packages (WhatsApp / WhatsApp Business, etc.). */
    fun installedPackage(app: AppKey): String? = app.packages.firstOrNull { pm.getLaunchIntentForPackage(it) != null }

    fun launch(app: AppKey): Boolean = intentFor(app)?.let { start(it) } ?: false

    fun start(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(intent); true
    } catch (e: Exception) { false }

    fun icon(app: AppKey): Drawable? =
        app.packages.firstNotNullOfOrNull { runCatching { pm.getApplicationIcon(it) }.getOrNull() }
            ?: intentFor(app)?.let { pm.resolveActivity(it, 0)?.loadIcon(pm) }
}
