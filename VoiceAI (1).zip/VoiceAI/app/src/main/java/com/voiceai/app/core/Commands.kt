package com.voiceai.app.core

import com.voiceai.app.data.Status

/** Every action VoiceAI can perform. Anything else is Unknown and is never executed. */
sealed interface Command {
    data class OpenApp(val app: AppKey) : Command
    data class SendMessage(val app: AppKey, val contact: String?, val message: String?) : Command
    data class Call(val contact: String?) : Command
    data class Search(val engine: AppKey, val query: String?) : Command
    data class Unknown(val text: String) : Command
}

data class ActionResult(
    val status: Status,
    val speech: String,
    val summary: String,
    val needsSettings: Boolean = false,
)

/** The executor talks to the user only through this interface (implemented by the ViewModel). */
interface Interaction {
    suspend fun confirm(title: String, detail: String, okLabel: String): Boolean
    suspend fun choose(title: String, options: List<String>): Int?
}
