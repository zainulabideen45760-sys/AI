package com.voiceai.app.core

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Phone

data class ContactMatch(val name: String, val number: String, val normalized: String?)

/** Read-only contact lookup, only run after the user grants Contacts permission. Nothing is stored or uploaded. */
class ContactResolver(private val ctx: Context) {
    fun find(query: String): List<ContactMatch> {
        val out = LinkedHashMap<String, ContactMatch>()
        val proj = arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER, Phone.NORMALIZED_NUMBER)
        ctx.contentResolver.query(Phone.CONTENT_URI, proj, "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$query%"), "${Phone.DISPLAY_NAME} ASC")?.use { c ->
            while (c.moveToNext() && out.size < 6) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                out.putIfAbsent(name.lowercase(), ContactMatch(name, number, c.getString(2)))
            }
        }
        return out.values.toList()
    }
}
