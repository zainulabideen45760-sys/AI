package com.voiceai.app.core

/**
 * Offline rule-based command understanding for English, Urdu script and Roman Urdu (and mixes).
 * It only ever produces commands from the fixed [Command] allowlist.
 */
object LocalParser {
    private val OPEN = setOf("kholo", "khol", "kholna", "kholiye", "kholein", "open", "launch", "chalao", "chala", "start", "run",
        "اوپن", "کھولو", "کھول", "کھولیں", "چلاؤ", "چلا")
    private val CALL = setOf("call", "phone", "ring", "dial", "کال", "فون")
    private val MSG = setOf("message", "msg", "mesg", "messege", "text", "میسج", "پیغام")
    private val SEARCH = setOf("search", "dhundo", "dhoondo", "dhundho", "find", "look", "سرچ", "تلاش", "ڈھونڈو", "ڈھونڈ")
    private val FILLER = setOf("ko", "par", "pe", "per", "on", "for", "to", "in", "karo", "kro", "kar", "karna", "karein", "kijiye", "kijye",
        "do", "de", "dena", "please", "plz", "pls", "zara", "mujhe", "me", "ek", "a", "the", "about", "bhejo", "bhej", "send",
        "کو", "پر", "پہ", "کرو", "کریں", "کیجیے", "دو", "مجھے", "ذرا", "براہ", "مہربانی", "ایک", "کے", "لیے", "لئے", "کر", "جی", "بھیجو", "بھیج")
    private val CANCEL = setOf("cancel", "nahi", "nahin", "nahi chahiye", "stop", "never mind", "nevermind", "rehne do", "رہنے دو", "نہیں", "کینسل")
    private val APP_WORDS: Set<String> =
        AppKey.values().filter { it != AppKey.PHONE }.flatMap { it.aliases }.flatMap { it.split(" ") }.toSet()
    private val ALIASES: List<Pair<String, AppKey>> =
        AppKey.values().flatMap { k -> k.aliases.map { it to k } }.sortedByDescending { it.first.length }

    private val COMPOUND = Regex("\\s+(?:aur|and|phir|then|اور|پھر)\\s+", RegexOption.IGNORE_CASE)
    private val MSG_RX = Regex("(?<!\\p{L})(message|msg|mesg|messege|text|میسج|پیغام)(?!\\p{L})", RegexOption.IGNORE_CASE)
    private val BODY_RX = Regex("(?<!\\p{L})(?:ke|keh|kay|that|saying|says|کہ)(?!\\p{L})\\s+(.+)",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val KO_RX = Regex("^(.*?)\\s(?:ko|کو)(?:\\s|$)")
    private val TO_RX = Regex("(?:^|\\s)to\\s+(.+)$")

    fun norm(s: String) = s.lowercase().replace(Regex("[.,!?؟،۔;:\"“”()]"), " ").replace(Regex("\\s+"), " ").trim()
    fun isCancel(s: String) = norm(s) in CANCEL

    private fun titleCase(s: String) = s.split(" ").filter { it.isNotBlank() }.joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }

    private fun strip(tokens: List<String>, left: Set<String>, right: Set<String> = left): List<String> {
        var a = 0; var b = tokens.size
        while (a < b && tokens[a] in left) a++
        while (b > a && tokens[b - 1] in right) b--
        return tokens.subList(a, b)
    }

    private fun detectApp(n: String): AppKey? {
        val p = " $n "
        return ALIASES.firstOrNull { p.contains(" ${it.first} ") }?.second
    }

    fun parse(text: String): List<Command> {
        val t = text.trim()
        if (t.isEmpty()) return listOf(Command.Unknown(text))
        COMPOUND.find(t)?.let { m ->
            val left = parseSingle(t.substring(0, m.range.first))
            val right = parseSingle(t.substring(m.range.last + 1))
            if (left is Command.OpenApp && right !is Command.Unknown) {
                val same = (right is Command.SendMessage && right.app == left.app) || (right is Command.Search && right.engine == left.app)
                return if (same) listOf(right) else listOf(left, right)
            }
        }
        return listOf(parseSingle(t))
    }

    private fun parseSingle(text: String): Command {
        val n = norm(text)
        if (n.isEmpty()) return Command.Unknown(text)
        val tokens = n.split(" ")
        val app = detectApp(n)
        val si = tokens.indexOfFirst { it in SEARCH }
        val mi = tokens.indexOfFirst { it in MSG }
        val hasOpen = tokens.any { it in OPEN }
        val hasCall = tokens.any { it in CALL }
        return when {
            si >= 0 && (mi < 0 || si < mi) -> {
                val engine = if (app == AppKey.YOUTUBE) AppKey.YOUTUBE else AppKey.GOOGLE
                val own = app?.aliases?.flatMap { it.split(" ") }?.toSet() ?: emptySet()
                val q = strip(tokens, FILLER + SEARCH + OPEN + APP_WORDS, FILLER + SEARCH + OPEN + own).joinToString(" ")
                Command.Search(engine, q.ifBlank { null })
            }
            mi >= 0 -> parseMessage(text, app)
            hasCall && !hasOpen -> {
                val cand = KO_RX.find(n)?.groupValues?.get(1) ?: n
                val name = strip(cand.split(" "), FILLER + CALL + APP_WORDS + OPEN).joinToString(" ")
                Command.Call(name.ifBlank { null }?.let(::titleCase))
            }
            hasOpen && app == null && tokens.any { it == "phone" || it == "فون" } -> Command.OpenApp(AppKey.PHONE)
            app != null && (hasOpen || tokens.size <= 2) -> Command.OpenApp(app)
            else -> Command.Unknown(text)
        }
    }

    private fun parseMessage(text: String, app: AppKey?): Command {
        val mm = MSG_RX.find(text) ?: return Command.Unknown(text)
        val before = text.substring(0, mm.range.first)
        val after = text.substring(mm.range.last + 1)
        val body = BODY_RX.find(after)
        val head = norm(before + " " + after.substring(0, body?.range?.first ?: after.length))
        val cand = KO_RX.find(head)?.groupValues?.get(1) ?: TO_RX.find(head)?.groupValues?.get(1) ?: head
        val name = strip(cand.split(" "), FILLER + APP_WORDS + OPEN + CALL + MSG).joinToString(" ")
        return Command.SendMessage(app ?: AppKey.WHATSAPP, name.ifBlank { null }?.let(::titleCase), body?.groupValues?.get(1)?.let(::cleanMessage))
    }

    // ---- helpers for answers to follow-up questions ----
    fun extractName(text: String): String {
        val n = strip(norm(text).split(" "), FILLER + APP_WORDS + OPEN + CALL + MSG).joinToString(" ")
        return titleCase(n.ifBlank { text.trim() })
    }
    fun cleanMessage(text: String): String {
        var s = text.trim().replace(Regex("^(?:ke|keh|kay|that|کہ)\\s+", RegexOption.IGNORE_CASE), "")
        if (s.isEmpty()) return s
        s = s.replaceFirstChar { it.uppercase() }
        if (s.last().let { it.isLetterOrDigit() && it.code < 0x600 }) s += "."
        return s
    }
    fun cleanQuery(text: String): String =
        strip(norm(text).split(" "), FILLER + SEARCH + OPEN + APP_WORDS, FILLER + SEARCH + OPEN).joinToString(" ").ifBlank { text.trim() }
}
