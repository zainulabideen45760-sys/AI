package com.voiceai.app.core

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

enum class SpeechError { NO_PERMISSION, NO_MATCH, NETWORK, UNAVAILABLE, BUSY, OTHER }

sealed interface SpeechEvent {
    data class Partial(val text: String) : SpeechEvent
    data class Level(val value: Float) : SpeechEvent
    data class Final(val text: String) : SpeechEvent
    data class Error(val kind: SpeechError) : SpeechEvent
}

/** Push-to-talk speech-to-text using Android's SpeechRecognizer. Must be collected on the main thread. */
class SpeechService(private val ctx: Context) {
    private var current: SpeechRecognizer? = null

    fun isAvailable() = SpeechRecognizer.isRecognitionAvailable(ctx)
    fun stop() { current?.stopListening() }

    fun listen(languageTag: String): Flow<SpeechEvent> = callbackFlow {
        val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
        current = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) { trySend(SpeechEvent.Level(((rms + 2f) / 12f).coerceIn(0f, 1f))) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { trySend(SpeechEvent.Partial(it)) }
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                trySend(if (t.isNullOrBlank()) SpeechEvent.Error(SpeechError.NO_MATCH) else SpeechEvent.Final(t))
                close()
            }
            override fun onError(code: Int) {
                val k = when (code) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> SpeechError.NO_PERMISSION
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> SpeechError.NO_MATCH
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> SpeechError.NETWORK
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> SpeechError.BUSY
                    12, 13 -> SpeechError.UNAVAILABLE // language not supported / unavailable
                    else -> SpeechError.OTHER
                }
                trySend(SpeechEvent.Error(k)); close()
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        rec.startListening(i)
        awaitClose { current = null; rec.destroy() }
    }
}
