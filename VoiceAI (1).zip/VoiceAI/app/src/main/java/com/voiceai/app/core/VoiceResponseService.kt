package com.voiceai.app.core

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.voiceai.app.data.Prefs
import com.voiceai.app.data.VoiceKind
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/** Text-to-speech wrapper. Volume follows the system media volume. */
class VoiceResponseService(ctx: Context, private val prefs: Prefs) {
    private var ready = false
    private val waiting = ConcurrentHashMap<String, () -> Unit>()
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(ctx.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            if (ready) tts.language = Locale.getDefault().takeIf { tts.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE } ?: Locale.US
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { id?.let { waiting.remove(it)?.invoke() } }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { id?.let { waiting.remove(it)?.invoke() } }
        })
    }

    private fun configure() {
        val s = prefs.current
        tts.setSpeechRate(s.speed.rate)
        if (s.voice == VoiceKind.SYSTEM) return
        val key = if (s.voice == VoiceKind.FEMALE) "female" else "male"
        // Best effort: voices only expose gender hints in their names on some devices.
        tts.voices?.firstOrNull { it.locale.language == tts.language?.language && it.name.contains(key, true) && !(key == "male" && it.name.contains("female", true)) }
            ?.let { tts.voice = it }
    }

    fun speakNow(text: String) {
        if (!ready) return
        configure(); tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    suspend fun speak(text: String) {
        if (!ready || text.isBlank()) return
        configure()
        suspendCancellableCoroutine<Unit> { c ->
            val id = UUID.randomUUID().toString()
            waiting[id] = { if (c.isActive) c.resume(Unit) }
            c.invokeOnCancellation { waiting.remove(id); tts.stop() }
            if (tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.ERROR) { waiting.remove(id); c.resume(Unit) }
        }
    }

    fun stop() { tts.stop() }
}
