package com.voiceai.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class Lang(val label: String, val tag: String) {
    ENGLISH("English", "en-US"), URDU("Urdu (اردو)", "ur-PK"), ROMAN("Roman Urdu", "en-IN")
}
enum class Speed(val label: String, val rate: Float) { SLOW("Slow", 0.8f), NORMAL("Normal", 1f), FAST("Fast", 1.3f) }
enum class VoiceKind(val label: String) { SYSTEM("System voice"), FEMALE("Female"), MALE("Male") }
enum class ThemeMode(val label: String) { CREAM("Cream"), SYSTEM("System default"), DARK("Dark mode") }

data class AppSettings(
    val onboarded: Boolean = false,
    val language: Lang = Lang.ENGLISH,
    val speed: Speed = Speed.NORMAL,
    val voice: VoiceKind = VoiceKind.SYSTEM,
    val confirmImportant: Boolean = true,
    val autoOpen: Boolean = true,
    val saveHistory: Boolean = true,
    val cloudAi: Boolean = false,
    val theme: ThemeMode = ThemeMode.CREAM,
    val favoriteApps: Set<String> = emptySet(),
    /** Used to turn local numbers like 0300… into international form for WhatsApp links. */
    val countryCode: String = "92",
)

/** Non-sensitive preferences. No secrets, tokens or API keys are stored here. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("voiceai_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state
    val current: AppSettings get() = _state.value

    fun update(f: (AppSettings) -> AppSettings) {
        val n = f(_state.value); _state.value = n; save(n)
    }

    private inline fun <reified E : Enum<E>> enumOf(key: String, def: E): E =
        runCatching { enumValueOf<E>(sp.getString(key, def.name)!!) }.getOrDefault(def)

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            onboarded = sp.getBoolean("onboarded", d.onboarded),
            language = enumOf("language", d.language),
            speed = enumOf("speed", d.speed),
            voice = enumOf("voice", d.voice),
            confirmImportant = sp.getBoolean("confirmImportant", d.confirmImportant),
            autoOpen = sp.getBoolean("autoOpen", d.autoOpen),
            saveHistory = sp.getBoolean("saveHistory", d.saveHistory),
            cloudAi = sp.getBoolean("cloudAi", d.cloudAi),
            theme = enumOf("theme", d.theme),
            favoriteApps = sp.getStringSet("favoriteApps", emptySet()) ?: emptySet(),
            countryCode = sp.getString("countryCode", d.countryCode) ?: d.countryCode,
        )
    }

    private fun save(s: AppSettings) {
        sp.edit()
            .putBoolean("onboarded", s.onboarded).putString("language", s.language.name)
            .putString("speed", s.speed.name).putString("voice", s.voice.name)
            .putBoolean("confirmImportant", s.confirmImportant).putBoolean("autoOpen", s.autoOpen)
            .putBoolean("saveHistory", s.saveHistory).putBoolean("cloudAi", s.cloudAi)
            .putString("theme", s.theme.name).putStringSet("favoriteApps", s.favoriteApps)
            .putString("countryCode", s.countryCode).apply()
    }
}
