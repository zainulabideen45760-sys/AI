package com.voiceai.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class Status { COMPLETED, PREPARED, FAILED, CANCELLED }

data class HistoryItem(val id: Long, val command: String, val action: String, val time: Long, val status: Status)
data class Fav(val id: Long, val text: String)
data class Shortcut(val id: Long, val name: String, val apps: List<String>)

/** Local SQLite storage for history, favorite commands and custom shortcuts. Nothing leaves the device. */
class Store(context: Context) : SQLiteOpenHelper(context, "voiceai.db", null, 1) {
    private val _history = MutableStateFlow<List<HistoryItem>>(emptyList())
    private val _favs = MutableStateFlow<List<Fav>>(emptyList())
    private val _shortcuts = MutableStateFlow<List<Shortcut>>(emptyList())
    val history: StateFlow<List<HistoryItem>> = _history
    val favorites: StateFlow<List<Fav>> = _favs
    val shortcuts: StateFlow<List<Shortcut>> = _shortcuts

    init { refreshAll() }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, command TEXT, action TEXT, time INTEGER, status TEXT)")
        db.execSQL("CREATE TABLE favorites(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT UNIQUE)")
        db.execSQL("CREATE TABLE shortcuts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, apps TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    private fun refreshAll() { refreshHistory(); refreshFavs(); refreshShortcuts() }

    private fun refreshHistory() {
        val out = ArrayList<HistoryItem>()
        readableDatabase.rawQuery("SELECT id,command,action,time,status FROM history ORDER BY time DESC LIMIT 300", null).use { c ->
            while (c.moveToNext()) out += HistoryItem(
                c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3),
                runCatching { Status.valueOf(c.getString(4)) }.getOrDefault(Status.FAILED)
            )
        }
        _history.value = out
    }
    private fun refreshFavs() {
        val out = ArrayList<Fav>()
        readableDatabase.rawQuery("SELECT id,text FROM favorites ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out += Fav(c.getLong(0), c.getString(1) ?: "")
        }
        _favs.value = out
    }
    private fun refreshShortcuts() {
        val out = ArrayList<Shortcut>()
        readableDatabase.rawQuery("SELECT id,name,apps FROM shortcuts ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out += Shortcut(c.getLong(0), c.getString(1) ?: "", (c.getString(2) ?: "").split(",").filter { it.isNotBlank() })
        }
        _shortcuts.value = out
    }

    fun addHistory(command: String, action: String, status: Status) {
        val v = ContentValues().apply {
            put("command", command); put("action", action); put("time", System.currentTimeMillis()); put("status", status.name)
        }
        writableDatabase.insert("history", null, v)
        writableDatabase.execSQL("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY time DESC LIMIT 500)")
        refreshHistory()
    }
    fun clearHistory() { writableDatabase.delete("history", null, null); refreshHistory() }

    fun addFavorite(text: String) {
        val t = text.trim(); if (t.isEmpty()) return
        writableDatabase.insertWithOnConflict("favorites", null, ContentValues().apply { put("text", t) }, SQLiteDatabase.CONFLICT_IGNORE)
        refreshFavs()
    }
    fun deleteFavorite(id: Long) { writableDatabase.delete("favorites", "id=?", arrayOf(id.toString())); refreshFavs() }

    fun addShortcut(name: String, apps: List<String>) {
        if (name.isBlank() || apps.isEmpty()) return
        writableDatabase.insert("shortcuts", null, ContentValues().apply { put("name", name.trim()); put("apps", apps.joinToString(",")) })
        refreshShortcuts()
    }
    fun deleteShortcut(id: Long) { writableDatabase.delete("shortcuts", "id=?", arrayOf(id.toString())); refreshShortcuts() }
}
