package com.voiceai.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.voiceai.app.AssistantViewModel
import com.voiceai.app.VoiceAIApp

@Composable
fun AppRoot(vm: AssistantViewModel = viewModel()) {
    val nav = rememberNavController()
    val prefs = VoiceAIApp.of(LocalContext.current).prefs
    NavHost(nav, "splash", enterTransition = { fadeIn(tween(350)) }, exitTransition = { fadeOut(tween(250)) }) {
        composable("splash") {
            SplashScreen { nav.navigate(if (prefs.current.onboarded) "main" else "onboarding") { popUpTo("splash") { inclusive = true } } }
        }
        composable("onboarding") { OnboardingScreen { nav.navigate("permissions") } }
        composable("permissions") {
            PermissionsScreen { prefs.update { it.copy(onboarded = true) }; nav.navigate("main") { popUpTo("onboarding") { inclusive = true } } }
        }
        composable("main") { MainScreen(vm) }
    }
}

@Composable
private fun MainScreen(vm: AssistantViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val tabs = listOf("Home" to Icons.Default.Home, "Apps" to Icons.Default.Apps, "History" to Icons.Default.History, "Settings" to Icons.Default.Settings)
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, null) }, label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .5f),
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant, unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant),
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad)) {
            Crossfade(tab, label = "tab") { t ->
                when (t) {
                    0 -> HomeScreen(vm)
                    1 -> AppsScreen(vm) { tab = 0 }
                    2 -> HistoryScreen(vm)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }

    ui.confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { vm.answerConfirm(false) }, title = { Text(c.title) }, text = { Text(c.detail) },
            confirmButton = { Button(onClick = { vm.answerConfirm(true) }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.White)) { Text(c.okLabel) } },
            dismissButton = { TextButton(onClick = { vm.answerConfirm(false) }) { Text("Cancel") } },
        )
    }
    ui.choose?.let { c ->
        AlertDialog(
            onDismissRequest = { vm.answerChoose(null) }, title = { Text(c.title) },
            text = { Column { c.options.forEachIndexed { i, name ->
                Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { vm.answerChoose(i) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Text(name, style = MaterialTheme.typography.bodyLarge) }
            } } },
            confirmButton = {}, dismissButton = { TextButton(onClick = { vm.answerChoose(null) }) { Text("Cancel") } },
        )
    }
}
