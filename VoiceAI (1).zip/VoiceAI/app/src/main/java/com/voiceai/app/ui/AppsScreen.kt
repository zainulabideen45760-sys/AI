package com.voiceai.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.voiceai.app.AssistantViewModel
import com.voiceai.app.core.AppKey
import com.voiceai.app.core.Command

@Composable
fun AppsScreen(vm: AssistantViewModel, goHome: () -> Unit) {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Text("Apps", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Apps", "Favorites", "Shortcuts").forEachIndexed { i, t ->
                FilterChip(selected = sub == i, onClick = { sub = i }, label = { Text(t) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer, selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer))
            }
        }
        Spacer(Modifier.height(8.dp))
        when (sub) {
            0 -> InstalledApps(vm, goHome)
            1 -> FavoriteCommands(vm, goHome)
            else -> Shortcuts(vm, goHome)
        }
    }
}

@Composable
private fun AppIcon(vm: AssistantViewModel, app: AppKey) {
    val bmp = remember(app) { runCatching { vm.launcher.icon(app)?.toBitmap(96, 96)?.asImageBitmap() }.getOrNull() }
    if (bmp != null) Image(bmp, null, Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))) else GoldIconBadge(app.icon())
}

@Composable
private fun InstalledApps(vm: AssistantViewModel, goHome: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val installed = remember(tick) { AppKey.values().filter { vm.launcher.isInstalled(it) } }
    val sorted = installed.sortedByDescending { it.name in settings.favoriteApps }
    Text("Only apps installed on this device are shown.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
        if (sorted.isEmpty()) item { Text("No supported apps were found.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(sorted) { app ->
            val fav = app.name in settings.favoriteApps
            PremiumCard(Modifier.fillMaxWidth(), onClick = { vm.run("Open ${app.label}", listOf(Command.OpenApp(app))); goHome() }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(vm, app)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(app.label, style = MaterialTheme.typography.titleMedium)
                        Text(app.blurb, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { vm.toggleFavoriteApp(app.name) }) {
                        Icon(if (fav) Icons.Default.Star else Icons.Default.StarBorder, if (fav) "Remove ${app.label} from favorites" else "Add ${app.label} to favorites", tint = Gold)
                    }
                }
            }
        }
    }
}

@Composable
private fun FavoriteCommands(vm: AssistantViewModel, goHome: () -> Unit) {
    val favs by vm.favorites.collectAsStateWithLifecycle()
    var text by rememberSaveable { mutableStateOf("") }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(text, { text = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("e.g. Call Ali") }, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.width(8.dp))
        FilledIconButton(onClick = { vm.addFavorite(text); text = "" }, enabled = text.isNotBlank(), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Gold)) {
            Icon(Icons.Default.Add, "Save favorite command", tint = Color.White)
        }
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
        if (favs.isEmpty()) item { Text("Save commands you use often. Tap one to run it. You can also star commands from History.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(favs, key = { it.id }) { f ->
            PremiumCard(Modifier.fillMaxWidth(), onClick = { vm.submit(f.text); goHome() }) {
                Row(Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Mic, null, tint = Gold, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(12.dp))
                    Text(f.text, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    IconButton(onClick = { vm.deleteFavorite(f.id) }) { Icon(Icons.Default.Delete, "Delete ${f.text}", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }
}

@Composable
private fun Shortcuts(vm: AssistantViewModel, goHome: () -> Unit) {
    val list by vm.shortcuts.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }
    Button(onClick = { creating = true }, Modifier.fillMaxWidth().padding(top = 4.dp).heightIn(min = 48.dp), shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.White)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("New shortcut") }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
        if (list.isEmpty()) item { Text("A shortcut opens several apps with one phrase, like “Work Mode”. Say its name or tap it.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(list, key = { it.id }) { s ->
            val apps = s.apps.mapNotNull { AppKey.fromName(it) }
            PremiumCard(Modifier.fillMaxWidth(), onClick = { vm.submit(s.name); goHome() }) {
                Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, style = MaterialTheme.typography.titleMedium)
                        Text(apps.joinToString(" • ") { it.label }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { vm.deleteShortcut(s.id) }) { Icon(Icons.Default.Delete, "Delete ${s.name}", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }
    if (creating) NewShortcutDialog(vm, onDismiss = { creating = false })
}

@Composable
private fun NewShortcutDialog(vm: AssistantViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf(setOf<AppKey>()) }
    val options = remember { AppKey.values().filter { vm.launcher.isInstalled(it) } }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("New shortcut") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("Name (e.g. Work Mode)") }, singleLine = true)
                Spacer(Modifier.height(12.dp)); Text("Apps to open, in order", style = MaterialTheme.typography.labelMedium)
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(options) { app ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(app in chosen, { chosen = if (it) chosen + app else chosen - app }, colors = CheckboxDefaults.colors(checkedColor = Gold))
                            Text(app.label)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.addShortcut(name, chosen.toList().sortedBy { it.ordinal }.map { it.name }); onDismiss() }, enabled = name.isNotBlank() && chosen.isNotEmpty()) { Text("Save shortcut", color = Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
