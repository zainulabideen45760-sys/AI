package com.voiceai.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.voiceai.app.core.AppKey
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

fun AppKey.icon(): ImageVector = when (this) {
    AppKey.WHATSAPP -> Icons.Default.Chat
    AppKey.YOUTUBE -> Icons.Default.PlayCircle
    AppKey.TIKTOK -> Icons.Default.MusicNote
    AppKey.PHONE -> Icons.Default.Call
    AppKey.CAMERA -> Icons.Default.CameraAlt
    AppKey.GOOGLE -> Icons.Default.Search
    AppKey.CHROME -> Icons.Default.Public
    AppKey.MAPS -> Icons.Default.Place
    AppKey.GMAIL -> Icons.Default.Email
    AppKey.CALENDAR -> Icons.Default.CalendarMonth
    AppKey.SETTINGS -> Icons.Default.Settings
}

fun sparkle(c: Offset, r: Float) = Path().apply {
    moveTo(c.x, c.y - r)
    quadraticBezierTo(c.x, c.y, c.x + r, c.y)
    quadraticBezierTo(c.x, c.y, c.x, c.y + r)
    quadraticBezierTo(c.x, c.y, c.x - r, c.y)
    quadraticBezierTo(c.x, c.y, c.x, c.y - r)
    close()
}

/** Minimal microphone outline with an AI sparkle — shared by the logo, splash and onboarding art. */
fun DrawScope.drawMic(center: Offset, s: Float, color: Color, withSparkle: Boolean = true) {
    val sw = s * 0.045f
    val c = Offset(center.x - s * 0.04f, center.y - s * 0.04f)
    val bw = s * 0.26f; val bh = s * 0.46f; val top = c.y - s * 0.30f
    drawRoundRect(color, Offset(c.x - bw / 2, top), Size(bw, bh), CornerRadius(bw / 2), style = Stroke(sw, cap = StrokeCap.Round))
    val r = s * 0.20f; val cy = top + bh - s * 0.06f
    drawArc(color, 0f, 180f, false, Offset(c.x - r, cy - r), Size(2 * r, 2 * r), style = Stroke(sw, cap = StrokeCap.Round))
    drawLine(color, Offset(c.x, cy + r), Offset(c.x, cy + r + s * 0.08f), sw, StrokeCap.Round)
    drawLine(color, Offset(c.x - s * 0.10f, cy + r + s * 0.08f), Offset(c.x + s * 0.10f, cy + r + s * 0.08f), sw, StrokeCap.Round)
    if (withSparkle) drawPath(sparkle(Offset(c.x + s * 0.32f, top + s * 0.02f), s * 0.11f), color, style = Fill)
}

@Composable
fun VoiceAILogo(modifier: Modifier = Modifier) {
    val outline = MaterialTheme.colorScheme.outline
    val bg = MaterialTheme.colorScheme.surfaceVariant
    Canvas(modifier.aspectRatio(1f)) {
        drawRoundRect(bg, cornerRadius = CornerRadius(size.minDimension * 0.28f))
        drawRoundRect(outline, cornerRadius = CornerRadius(size.minDimension * 0.28f), style = Stroke(size.minDimension * 0.015f))
        drawMic(center, size.minDimension, Gold)
    }
}

@Composable
fun PremiumCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val base = modifier.shadow(2.dp, shape, ambientColor = Gold.copy(alpha = .25f), spotColor = Gold.copy(alpha = .25f))
        .clip(shape).border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
        .background(MaterialTheme.colorScheme.surface)
    Column(if (onClick != null) base.clickable(onClick = onClick) else base, content = content)
}

@Composable
fun GoldIconBadge(icon: ImageVector, size: Int = 40, desc: String? = null) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f)), Alignment.Center) {
        Icon(icon, desc, tint = Gold, modifier = Modifier.size((size * 0.52f).dp))
    }
}

@Composable
fun Waveform(level: Float, modifier: Modifier = Modifier) {
    val phase by rememberInfiniteTransition(label = "wave").animateFloat(
        0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "phase")
    val lv by animateFloatAsState(level, label = "level")
    Canvas(modifier.height(48.dp).fillMaxWidth(0.7f)) {
        val n = 25; val bw = size.width / (n * 2f)
        for (i in 0 until n) {
            val h = (size.height * (0.12f + 0.88f * abs(sin(phase + i * 0.55f)) * (0.2f + 0.8f * lv))).coerceAtMost(size.height)
            drawRoundRect(Gold.copy(alpha = 0.55f + 0.45f * lv), Offset(i * 2 * bw, (size.height - h) / 2), Size(bw, h), CornerRadius(bw / 2))
        }
    }
}

@Composable
fun SuccessCheck(modifier: Modifier = Modifier, color: Color = Gold) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(450, easing = FastOutSlowInEasing)) }
    Canvas(modifier.size(28.dp)) {
        drawCircle(color, size.minDimension / 2 - 1.5f, style = Stroke(3f))
        val a = Offset(size.width * .28f, size.height * .52f); val b = Offset(size.width * .44f, size.height * .68f); val c = Offset(size.width * .74f, size.height * .34f)
        val t = p.value
        val path = Path().apply {
            moveTo(a.x, a.y)
            if (t < .4f) lineTo(a.x + (b.x - a.x) * t / .4f, a.y + (b.y - a.y) * t / .4f)
            else { lineTo(b.x, b.y); val u = (t - .4f) / .6f; lineTo(b.x + (c.x - b.x) * u, b.y + (c.y - b.y) * u) }
        }
        drawPath(path, color, style = Stroke(3.2f, cap = StrokeCap.Round))
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier.padding(start = 4.dp, top = 22.dp, bottom = 8.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
