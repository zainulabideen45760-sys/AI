package com.voiceai.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.voiceai.app.AssistantViewModel
import com.voiceai.app.data.Status
import java.text.SimpleDateFormat
import java.util.*

private fun whenText(t: Long): String {
    val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(t))
    val now = Calendar.getInstance(); val c = Calendar.getInstance().apply { timeInMillis = t }
    fun day(x: Calendar) = x.get(Calendar.YEAR) * 1000 + x.get(Calendar.DAY_OF_YEAR)
    val yest = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) }
    return when (day(c)) {
        day(now) -> "Today, $time"
        day(yest) -> "Yesterday, $time"
        else -> SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(t))
    }
}

@Composable
fun HistoryScreen(vm: AssistantViewModel) {
    val items by vm.history.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("History", Modifier.weight(1f), style = MaterialTheme.typography.headlineMedium)
            if (items.isNotEmpty()) IconButton(onClick = { confirmClear = true }) { Icon(Icons.Default.Delete, "Clear history", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    GoldIconBadge(Icons.Default.History, 56)
                    Spacer(Modifier.height(12.dp))
                    Text("No commands yet", style = MaterialTheme.typography.titleMedium)
                    Text("Tap the microphone on Home to give your first command.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            items(items, key = { it.id }) { h ->
                PremiumCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("“${h.command}”", style = MaterialTheme.typography.titleMedium)
                            Text(h.action, style = MaterialTheme.typography.bodyMedium)
                            Text(whenText(h.time), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(4.dp))
                            val (txt, col) = when (h.status) {
                                Status.COMPLETED -> "✓ Completed" to Gold
                                Status.PREPARED -> "✓ Ready in app" to Gold
                                Status.FAILED -> "⚠ Failed" to MaterialTheme.colorScheme.error
                                Status.CANCELLED -> "Cancelled" to MaterialTheme.colorScheme.onSurfaceVariant
                            }
                            Text(txt, color = col, style = MaterialTheme.typography.labelLarge)
                        }
                        IconButton(onClick = { vm.addFavorite(h.command) }) { Icon(Icons.Default.StarBorder, "Save “${h.command}” as favorite", tint = Gold) }
                    }
                }
            }
        }
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false }, title = { Text("Clear history?") }, text = { Text("This removes all saved commands from this device.") },
        confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Clear", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } })
}
