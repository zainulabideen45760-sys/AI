package com.voiceai.app.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.voiceai.app.AssistantViewModel
import com.voiceai.app.Phase
import com.voiceai.app.ReplyKind
import com.voiceai.app.core.AppKey
import java.util.Calendar

private val examples = listOf("WhatsApp kholo", "YouTube open karo", "Ali ko call karo", "Ali ko WhatsApp message karo", "Google par search karo", "Camera kholo", "TikTok chalao")
private val quickApps = listOf(AppKey.WHATSAPP, AppKey.YOUTUBE, AppKey.TIKTOK, AppKey.PHONE, AppKey.CAMERA, AppKey.GOOGLE)

@Composable
fun HomeScreen(vm: AssistantViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.onMic() else vm.micDenied() }
    fun tap() { if (ui.phase != Phase.IDLE || ctx.hasPermission(Manifest.permission.RECORD_AUDIO)) vm.onMic() else micPerm.launch(Manifest.permission.RECORD_AUDIO) }

    val greeting = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) { in 5..11 -> "Good morning"; in 12..16 -> "Good afternoon"; in 17..20 -> "Good evening"; else -> "Hello" }
    val label = when (ui.phase) { Phase.IDLE -> "Tap to speak"; Phase.LISTENING -> "Listening…"; Phase.UNDERSTANDING, Phase.PREPARING -> "Thinking…"; Phase.SPEAKING -> "Speaking…" }
    val sub = when (ui.phase) { Phase.UNDERSTANDING -> "Understanding…"; Phase.PREPARING -> "Preparing your action…"; else -> "" }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            VoiceAILogo(Modifier.size(34.dp)); Spacer(Modifier.width(10.dp))
            Text("VoiceAI", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(24.dp))
        Text(greeting, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("How can I help?", style = MaterialTheme.typography.headlineLarge)
        Text("Tap the microphone and speak.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))

        MicButton(ui.phase, label, ::tap)
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(8.dp))
            Text(label, style = MaterialTheme.typography.titleMedium)
            if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            AnimatedVisibility(ui.phase == Phase.LISTENING) { Box(Modifier.padding(top = 12.dp)) { Waveform(ui.level) } }
        }

        val shown = if (ui.partial.isNotBlank()) ui.partial else ui.heard
        if (shown.isNotBlank()) {
            Spacer(Modifier.height(16.dp))
            PremiumCard(Modifier.fillMaxWidth()) { Text("“$shown”", Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge) }
        }
        Spacer(Modifier.height(12.dp))
        if (ui.reply.isNotBlank()) {
            PremiumCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                    when (ui.replyKind) {
                        ReplyKind.SUCCESS -> SuccessCheck()
                        ReplyKind.ERROR -> Icon(Icons.Default.Warning, "Problem", tint = MaterialTheme.colorScheme.error)
                        else -> Icon(Icons.Default.AutoAwesome, null, tint = Gold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(ui.reply, style = MaterialTheme.typography.bodyLarge)
                        if (ui.replyNeedsSettings) TextButton(onClick = { ctx.openAppSettings() }, contentPadding = PaddingValues(0.dp)) { Text("Open Settings", color = Gold) }
                    }
                }
            }
        } else if (ui.phase == Phase.IDLE && shown.isBlank()) {
            Text("Ready when you are.", Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }

        SectionLabel("Try saying")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(examples) { e ->
                AssistChip(onClick = { vm.submit(e) }, label = { Text(e) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = AssistChipDefaults.assistChipBorder(true, borderColor = MaterialTheme.colorScheme.outline))
            }
        }

        SectionLabel("Quick actions")
        quickApps.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { app ->
                    PremiumCard(Modifier.weight(1f), onClick = { vm.quick(app) }) {
                        Column(Modifier.padding(14.dp).semantics { contentDescription = "${app.label}. ${app.blurb}" }) {
                            GoldIconBadge(app.icon(), 38)
                            Spacer(Modifier.height(10.dp))
                            Text(app.label, style = MaterialTheme.typography.titleMedium)
                            Text(app.blurb, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun MicButton(phase: Phase, label: String, onClick: () -> Unit) {
    val listening = phase == Phase.LISTENING
    val busy = phase == Phase.UNDERSTANDING || phase == Phase.PREPARING
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        1f, if (listening) 1.14f else 1.06f,
        infiniteRepeatable(tween(if (listening) 800 else 2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "scale")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 0.94f else 1f, label = "press")
    BoxWithConstraints(Modifier.fillMaxWidth(), Alignment.Center) {
        val d = (maxWidth * 0.56f).coerceIn(150.dp, 230.dp)
        Box(Modifier.size(d).scale(press), Alignment.Center) {
            Box(Modifier.fillMaxSize().scale(pulse).background(Gold.copy(alpha = 0.16f), CircleShape))
            Box(Modifier.fillMaxSize(0.84f).shadow(14.dp, CircleShape, ambientColor = Gold, spotColor = Gold).background(MaterialTheme.colorScheme.surface, CircleShape), Alignment.Center) {
                Box(
                    Modifier.fillMaxSize(0.72f).background(Gold, CircleShape)
                        .semantics { contentDescription = "Microphone. $label" }
                        .clickable(src, null, role = Role.Button, onClick = onClick),
                    Alignment.Center,
                ) {
                    if (busy) CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.fillMaxSize(0.5f))
                    else Icon(Icons.Default.Mic, null, tint = Color.White, modifier = Modifier.fillMaxSize(0.42f))
                }
            }
        }
    }
}
