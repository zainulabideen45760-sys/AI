package com.voiceai.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sin

const val TAGLINE = "Your Voice. Your Phone. Your Control."

fun Context.openAppSettings() {
    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(900, easing = FastOutSlowInEasing)); delay(1000); onDone() }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding(), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            VoiceAILogo(Modifier.size(128.dp).scale(0.85f + 0.15f * p.value).alpha(p.value))
            Spacer(Modifier.height(24.dp))
            Text("VoiceAI", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.alpha(p.value))
            Spacer(Modifier.height(8.dp))
            Text(TAGLINE, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center, modifier = Modifier.alpha((p.value - 0.4f).coerceAtLeast(0f) / 0.6f))
        }
    }
}

private data class Page(val title: String, val body: String)
private val pages = listOf(
    Page("Meet VoiceAI", "Your intelligent voice assistant for everyday phone tasks."),
    Page("Just Speak", "Open apps, search the web, make calls and perform supported actions using your voice."),
    Page("Your Assistant, Your Control", "VoiceAI works with permissions you choose and keeps your actions transparent."),
)

@Composable
private fun Illustration(page: Int, modifier: Modifier) {
    val t by rememberInfiniteTransition(label = "ill").animateFloat(0f, (2 * Math.PI).toFloat(), infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "t")
    val soft = MaterialTheme.colorScheme.primaryContainer
    Canvas(modifier) {
        val s = size.minDimension
        when (page) {
            0 -> {
                for (i in 3 downTo 1) drawCircle(soft.copy(alpha = 0.18f * (4 - i) + 0.05f * sin(t)), s * (0.22f + 0.12f * i))
                drawMic(center, s * 0.62f, Gold)
            }
            1 -> {
                drawMic(Offset(center.x, center.y - s * 0.12f), s * 0.5f, Gold, false)
                val n = 21; val bw = s * 0.7f / (n * 2); val x0 = center.x - s * 0.35f
                for (i in 0 until n) {
                    val env = 1f - abs(i - n / 2) / (n / 2f)
                    val h = s * 0.28f * (0.15f + 0.85f * env * abs(sin(t + i * 0.45f)))
                    drawRoundRect(Gold.copy(alpha = 0.4f + 0.6f * env), Offset(x0 + i * 2 * bw, center.y + s * 0.30f - h / 2), Size(bw, h), CornerRadius(bw / 2))
                }
            }
            else -> {
                val w = s * 0.46f; val h = s * 0.82f; val tl = Offset(center.x - w / 2, center.y - h / 2)
                drawRoundRect(Gold, tl, Size(w, h), CornerRadius(w * 0.16f), style = Stroke(s * 0.018f))
                drawRoundRect(Gold, Offset(center.x - w * 0.12f, tl.y + h * 0.04f), Size(w * 0.24f, h * 0.012f), CornerRadius(4f))
                drawMic(center, s * 0.4f, Gold)
                val b = Offset(center.x + w * 0.5f, center.y + h * 0.32f)
                drawCircle(Gold, s * 0.085f, b)
                val chk = Path().apply { moveTo(b.x - s * 0.04f, b.y); lineTo(b.x - s * 0.01f, b.y + s * 0.03f); lineTo(b.x + s * 0.045f, b.y - s * 0.03f) }
                drawPath(chk, Color.White, style = Stroke(s * 0.015f, cap = StrokeCap.Round))
            }
        }
    }
}

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val state = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(24.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onDone) { Text("Skip", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        HorizontalPager(state, Modifier.weight(1f)) { i ->
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Illustration(i, Modifier.fillMaxWidth(0.8f).aspectRatio(1f).widthIn(max = 320.dp))
                Spacer(Modifier.height(24.dp))
                Text(pages[i].title, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(pages[i].body, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalArrangement = Arrangement.Center) {
            repeat(pages.size) { i ->
                val on = state.currentPage == i
                Box(Modifier.padding(4.dp).height(8.dp).width(if (on) 24.dp else 8.dp).background(if (on) Gold else MaterialTheme.colorScheme.outline, CircleShape))
            }
        }
        val last = state.currentPage == pages.lastIndex
        Button(
            onClick = { if (last) onDone() else scope.launch { state.animateScrollToPage(state.currentPage + 1) } },
            modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp), shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.White),
        ) { Text(if (last) "Get Started" else "Next", style = MaterialTheme.typography.titleMedium) }
    }
}

private enum class Perm(val manifest: String, val title: String, val why: String, val without: String, val icon: ImageVector) {
    MIC(Manifest.permission.RECORD_AUDIO, "Microphone", "Lets VoiceAI hear your command, only after you tap the microphone.", "Voice commands won't work.", Icons.Default.Mic),
    CONTACTS(Manifest.permission.READ_CONTACTS, "Contacts", "Finds the person you ask to call or message. Contacts stay on your phone.", "Calling and messaging by name won't work.", Icons.Default.Person),
    PHONE(Manifest.permission.CALL_PHONE, "Phone", "Starts a call you've confirmed.", "Calls will open the dialer and you press call yourself.", Icons.Default.Call);
}

fun Context.hasPermission(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

@Composable
fun PermissionsScreen(onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(24.dp)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Spacer(Modifier.height(12.dp))
            Text("Set up permissions", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text("VoiceAI asks only for what it needs. You can change any of these later in Settings.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(20.dp))
            Perm.values().forEach { PermissionCard(it); Spacer(Modifier.height(12.dp)) }
            Text("VoiceAI doesn't use Accessibility or Notifications, and never reads your messages.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp), shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.White)) { Text("Continue", style = MaterialTheme.typography.titleMedium) }
    }
}

@Composable
private fun PermissionCard(p: Perm) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var denied by rememberSaveable { mutableStateOf(false) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val granted = remember(tick) { ctx.hasPermission(p.manifest) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> denied = !ok; tick++ }
    PremiumCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GoldIconBadge(p.icon)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.title, style = MaterialTheme.typography.titleMedium)
                    Text(p.why, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(12.dp))
            when {
                granted -> Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CheckCircle, null, tint = Gold, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text("Allowed", color = Gold, style = MaterialTheme.typography.labelLarge) }
                denied -> Column {
                    Text("Not allowed. ${p.without}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = { ctx.openAppSettings() }) { Text("Open Settings", color = Gold) }
                }
                else -> Button(onClick = { launcher.launch(p.manifest) }, shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.White)) { Text("Allow ${p.title}") }
            }
        }
    }
}
