package com.voiceai.app.ui

import android.Manifest
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.voiceai.app.AssistantViewModel
import com.voiceai.app.BuildConfig
import com.voiceai.app.data.*

@Composable
private fun Row2(title: String, sub: String? = null, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).heightIn(min = 56.dp).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing()
    }
}

@Composable
private fun Toggle(title: String, sub: String? = null, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) =
    Row2(title, sub, if (enabled) ({ onChange(!checked) }) else null) {
        Switch(checked, onChange, enabled = enabled, colors = SwitchDefaults.colors(checkedTrackColor = Gold, checkedThumbColor = Color.White))
    }

@Composable
private fun <T> ChoiceDialog(title: String, options: List<T>, selected: T, label: (T) -> String, onPick: (T) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { Column { options.forEach { o ->
            Row(Modifier.fillMaxWidth().clickable { onPick(o); onDismiss() }.heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(o == selected, { onPick(o); onDismiss() }, colors = RadioButtonDefaults.colors(selectedColor = Gold)); Text(label(o))
            } } } },
        confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}

@Composable
private fun InfoDialog(title: String, body: String, onDismiss: () -> Unit) =
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(body) } },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Gold) } })

private const val PRIVACY = """VoiceAI listens only after you tap the microphone, and the screen always shows when it is listening.

• Audio: speech recognition is done by your device's speech service (usually Google's), which may process audio online. VoiceAI does not record or store audio.
• Commands are understood on your device. If you turn on the optional Cloud AI (only available when a backend is configured), only the text of your command is sent — never audio, contacts or history.
• Contacts are searched locally only when you ask to call or message someone. They are never stored or uploaded.
• Messages and calls need your confirmation when "Confirm important actions" is on. For WhatsApp, VoiceAI prepares the message and you tap Send inside WhatsApp.
• History, favorites and shortcuts stay on this device. You can clear history at any time.
• VoiceAI never reads your messages, passwords or one-time codes."""

private const val TERMS = """Template terms — replace with your own legal text before publishing.

VoiceAI is provided "as is". You are responsible for the commands you give and the actions you confirm. VoiceAI relies on features offered by Android and third-party apps, which may change or be unavailable."""

private const val HELP = """Try saying:
• "WhatsApp kholo" / "Open WhatsApp"
• "Ali ko WhatsApp message karo ke main ghar aa raha hoon"
• "Ali ko call karo"
• "YouTube par funny videos search karo"
• "Google par search karo latest phones"
• "Camera kholo", "Settings kholo", "TikTok chalao"

Tips: speak after the mic turns gold, pick the right language in Settings → Voice, and make sure the Microphone and Contacts permissions are allowed."""

@Composable
fun SettingsScreen(vm: AssistantViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    var dialog by remember { mutableStateOf<String?>(null) }
    val cloudOk = vm.cloudAvailable

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 8.dp))

        SectionLabel("Voice")
        PremiumCard(Modifier.fillMaxWidth()) {
            Toggle("Voice Activation", "Not available in this version. Hands-free listening needs an always-on microphone service; VoiceAI uses push-to-talk so it never listens in secret.", false, enabled = false) {}
            Row2("Wake word", "“Hey VoiceAI” — not active (see above)")
            Row2("Language", s.language.label, { dialog = "lang" })
            Row2("Assistant voice", s.voice.label + " (depends on voices installed)", { dialog = "voice" })
            Row2("Speech speed", s.speed.label, { dialog = "speed" })
        }

        SectionLabel("Actions")
        PremiumCard(Modifier.fillMaxWidth()) {
            Toggle("Confirm important actions", "Ask before calling or sending a message.", s.confirmImportant) { v -> vm.updateSettings { it.copy(confirmImportant = v) } }
            Toggle("Auto open apps", "Off: ask before opening an app.", s.autoOpen) { v -> vm.updateSettings { it.copy(autoOpen = v) } }
            Toggle("Command history", "Save commands on this device.", s.saveHistory) { v -> vm.updateSettings { it.copy(saveHistory = v) } }
            Row2("Clear history", null, { vm.clearHistory() })
        }

        SectionLabel("Privacy")
        PremiumCard(Modifier.fillMaxWidth()) {
            Toggle("Cloud AI (optional)",
                if (cloudOk) "Sends only the text of your command to your configured backend for smarter understanding." else "Not configured in this build. Commands are understood on your device.",
                s.cloudAi && cloudOk, enabled = cloudOk) { v -> vm.updateSettings { it.copy(cloudAi = v) } }
        }

        SectionLabel("Permissions")
        PremiumCard(Modifier.fillMaxWidth()) {
            listOf(Manifest.permission.RECORD_AUDIO to "Microphone", Manifest.permission.READ_CONTACTS to "Contacts", Manifest.permission.CALL_PHONE to "Phone").forEach { (p, n) ->
                val ok = remember(tick) { ctx.hasPermission(p) }
                Row2(n, if (ok) "Allowed" else "Not allowed — related features won't work", { ctx.openAppSettings() }) { Text("Manage", color = Gold, style = MaterialTheme.typography.labelLarge) }
            }
            Row2("Notifications", "Not needed")
            Row2("Accessibility", "Not used — VoiceAI doesn't need it")
        }

        SectionLabel("Appearance")
        PremiumCard(Modifier.fillMaxWidth()) { Row2("Theme", s.theme.label, { dialog = "theme" }) }

        SectionLabel("About")
        PremiumCard(Modifier.fillMaxWidth()) {
            Row2("App version", BuildConfig.VERSION_NAME)
            Row2("Privacy", null, { dialog = "privacy" })
            Row2("Terms", null, { dialog = "terms" })
            Row2("Help & Support", null, { dialog = "help" })
        }
        Spacer(Modifier.height(24.dp))
    }

    when (dialog) {
        "lang" -> ChoiceDialog("Language", Lang.values().toList(), s.language, { it.label }, { v -> vm.updateSettings { it.copy(language = v) } }, { dialog = null })
        "voice" -> ChoiceDialog("Assistant voice", VoiceKind.values().toList(), s.voice, { it.label }, { v -> vm.updateSettings { it.copy(voice = v) } }, { dialog = null })
        "speed" -> ChoiceDialog("Speech speed", Speed.values().toList(), s.speed, { it.label }, { v -> vm.updateSettings { it.copy(speed = v) } }, { dialog = null })
        "theme" -> ChoiceDialog("Theme", ThemeMode.values().toList(), s.theme, { it.label }, { v -> vm.updateSettings { it.copy(theme = v) } }, { dialog = null })
        "privacy" -> InfoDialog("Privacy", PRIVACY) { dialog = null }
        "terms" -> InfoDialog("Terms", TERMS) { dialog = null }
        "help" -> InfoDialog("Help & Support", HELP) { dialog = null }
    }
}
