package com.voiceai.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Gold = Color(0xFFC8944A)
val LightGold = Color(0xFFE7C58E)
val CreamBg = Color(0xFFFFF8ED)
val CreamAlt = Color(0xFFF7EEDF)
val Ink = Color(0xFF171717)
val Muted = Color(0xFF77716A)
val Danger = Color(0xFFB3261E)

private val Light = lightColorScheme(
    primary = Gold, onPrimary = Color.White, primaryContainer = LightGold, onPrimaryContainer = Ink,
    secondary = Gold, background = CreamBg, onBackground = Ink, surface = Color.White, onSurface = Ink,
    surfaceVariant = CreamAlt, onSurfaceVariant = Muted, outline = Color(0xFFE5D8C3), outlineVariant = Color(0xFFEFE3CF),
    error = Danger, surfaceContainer = Color.White, surfaceContainerHigh = Color.White, surfaceContainerHighest = CreamAlt,
    surfaceContainerLow = Color.White, surfaceContainerLowest = Color.White,
)
private val Dark = darkColorScheme(
    primary = Gold, onPrimary = Color.White, primaryContainer = Color(0xFF4A3A22), onPrimaryContainer = LightGold,
    secondary = Gold, background = Ink, onBackground = Color.White, surface = Color(0xFF242424), onSurface = Color.White,
    surfaceVariant = Color(0xFF2E2E2E), onSurfaceVariant = Color(0xFFB5AEA5), outline = Color(0xFF3A3A3A), outlineVariant = Color(0xFF333333),
    error = Color(0xFFFFB4AB), surfaceContainer = Color(0xFF242424), surfaceContainerHigh = Color(0xFF2A2A2A),
    surfaceContainerHighest = Color(0xFF303030), surfaceContainerLow = Color(0xFF242424), surfaceContainerLowest = Color(0xFF1E1E1E),
)

private val Sans = FontFamily.SansSerif
private val Type = Typography(
    headlineLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 34.sp, lineHeight = 40.sp, letterSpacing = (-0.8).sp),
    headlineMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontFamily = Sans, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = Sans, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = Sans, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 14.sp),
    labelMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 12.sp),
)

@Composable
fun VoiceAITheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = Type, content = content)
}
